package com.example.sleep_well

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
